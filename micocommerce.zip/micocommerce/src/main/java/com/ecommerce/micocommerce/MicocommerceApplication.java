package com.ecommerce.micocommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicocommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicocommerceApplication.class, args);
	}

}
